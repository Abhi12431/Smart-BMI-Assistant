import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String _keyUserEmail = 'user_email';
  static const String _keyIsLoggedIn = 'is_logged_in';
  static const String _keyHasSignedUp = 'has_signed_up';

  // Predefined users list
  static const List<Map<String, String>> predefinedUsers = [
    {'email': 'user1@gmail.com', 'password': '1234'},
    {'email': 'user2@gmail.com', 'password': '1234'},
    {'email': 'user3@gmail.com', 'password': '1234'},
    {'email': 'user4@gmail.com', 'password': '1234'},
  ];

  // Check if email is in predefined list
  bool isPredefinedUser(String email) {
    return predefinedUsers.any((user) => user['email'] == email);
  }

  // Check if email and password match predefined user
  bool validateCredentials(String email, String password) {
    return predefinedUsers.any(
      (user) => user['email'] == email && user['password'] == password,
    );
  }

  // Sign up with email and password
  Future<bool> signUp({
    required String email,
    required String password,
  }) async {
    try {
      // Check if email is predefined
      if (!isPredefinedUser(email)) {
        return false;
      }

      // Check if password matches
      if (!validateCredentials(email, password)) {
        return false;
      }

      // Check if already signed up
      final prefs = await SharedPreferences.getInstance();
      final hasSignedUp = prefs.getBool(_keyHasSignedUp) ?? false;
      if (hasSignedUp) {
        return false; // Already signed up
      }

      // Save signup state
      await prefs.setBool(_keyHasSignedUp, true);
      await prefs.setString(_keyUserEmail, email);
      await prefs.setBool(_keyIsLoggedIn, true);

      return true;
    } catch (e) {
      throw Exception('Sign up failed: $e');
    }
  }

  // Login with email and password
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    try {
      // Validate against predefined users
      if (!validateCredentials(email, password)) {
        return false;
      }

      // Check if user has signed up
      final prefs = await SharedPreferences.getInstance();
      final hasSignedUp = prefs.getBool(_keyHasSignedUp) ?? false;
      if (!hasSignedUp) {
        return false; // Must sign up first
      }

      // Save session
      await prefs.setString(_keyUserEmail, email);
      await prefs.setBool(_keyIsLoggedIn, true);

      return true;
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyIsLoggedIn, false);
      // Keep signup state, just clear login session
    } catch (e) {
      throw Exception('Sign out failed: $e');
    }
  }

  // Get current user email
  Future<String?> get currentUserEmail async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUserEmail);
  }

  // Check if user is authenticated
  Future<bool> get isAuthenticated async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyIsLoggedIn) ?? false;
  }

  // Check if user has signed up
  Future<bool> get hasSignedUp async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyHasSignedUp) ?? false;
  }
}
