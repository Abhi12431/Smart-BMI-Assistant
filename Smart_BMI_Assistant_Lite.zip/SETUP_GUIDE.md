# Smart BMI Assistant - Setup Guide for Windows

## ⚠️ Important Note

This version uses **local storage only** with simple name-based authentication. This is suitable for:
- Testing UI
- College project demos
- Personal use

**NOT suitable for production use** as it lacks:
- Real authentication
- Backend validation
- Secure data storage

## 📋 Prerequisites

Before you begin, ensure you have the following installed on your Windows machine:

1. **Flutter SDK** (latest stable version)
   - Download from: https://flutter.dev/docs/get-started/install/windows
   - Extract to a location (e.g., `C:\flutter`)
   - Add Flutter to your PATH:
     - Search for "Environment Variables" in Windows
     - Edit "Path" under User variables
     - Add `C:\flutter\bin`

2. **Android Studio** (for Android development)
   - Download from: https://developer.android.com/studio
   - Install with Android SDK and Android Virtual Device (AVD)

3. **Git** (optional, for version control)
   - Download from: https://git-scm.com/download/win

4. **VS Code** (recommended IDE)
   - Download from: https://code.visualstudio.com/
   - Install Flutter and Dart extensions

## 🚀 Running the App

### 1. Install Dependencies

Open PowerShell or Command Prompt in the project directory:

```bash
cd C:\Users\abhin\CascadeProjects\2048
flutter pub get
```

### 2. Verify Flutter Setup

```bash
flutter doctor
```

Ensure all items show checkmarks. If not, follow the instructions to fix any issues.

### 3. Run on Android Emulator

1. Open Android Studio
2. Go to **Tools** → **Device Manager**
3. Create a new Virtual Device (AVD)
4. Start the emulator
5. Run the app:

```bash
flutter run
```

### 4. Run on Physical Android Device

1. Enable **USB Debugging** on your Android device:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times to enable Developer Options
   - Go to Developer Options
   - Enable "USB Debugging"
2. Connect your device via USB
3. Run the app:

```bash
flutter run
```

### 5. Run on Windows Desktop

```bash
flutter run -d windows
```

Note: You may need to enable Windows desktop support first:

```bash
flutter config --enable-windows-desktop
```

## 📱 App Features

### Authentication (Local Storage Only)
- **Sign Up**: Enter your name + profile details (age, height, weight, gender, goal)
- **Sign In**: Enter your name only
- **Logout**: Clears local data
- **Persistent Sessions**: Auto-login on app restart
- **Random Password**: Automatically generated for security (stored locally)

### BMI Calculator
- Input: Height (cm), Weight (kg), Age, Gender
- Instant BMI calculation
- BMI category display
- Results saved to local storage

### Progress Tracking
- BMI history stored locally
- Progress graphs using fl_chart
- Daily/weekly/monthly views
- Last 50 results stored

### Diet Planner
- Personalized meal plans based on BMI
- Breakfast, Lunch, Dinner suggestions
- Calorie estimates
- Categories: Weight Loss, Weight Gain, Maintenance

### User Profile
- Store personal information locally
- Edit profile details
- Health goals tracking

## 🐛 Troubleshooting

### Issue: Flutter command not found
**Solution:** Add Flutter to your PATH environment variable

### Issue: Build errors
**Solution:**
```bash
flutter clean
flutter pub get
flutter run
```

### Issue: Data not persisting
**Solution:** This is a local storage app. Data is stored on the device only. Clearing app data will remove all information.

### Issue: Cannot login after reinstall
**Solution:** Since this uses local storage, reinstalling the app clears all data. You'll need to sign up again.

## 📁 Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/
│   ├── bmi_result.dart      # BMI result model
│   └── user_profile.dart    # User profile model
├── screens/
│   ├── splash_screen.dart   # Splash screen
│   ├── login_screen.dart    # Login screen (name only)
│   ├── register_screen.dart # Registration screen (name + profile)
│   ├── bmi_calculator_screen.dart
│   ├── suggestions_screen.dart
│   ├── diet_planner_screen.dart
│   ├── history_screen.dart
│   └── profile_screen.dart
├── services/
│   ├── auth_service.dart    # Local authentication service
│   └── database_service.dart # Local storage operations
├── providers/
│   └── auth_provider.dart   # State management
└── utils/                    # Utility functions
```

## 🔐 Security Notes

⚠️ **This is a demo/local-only app:**
- No real authentication (name-based only)
- No backend validation
- Data stored locally on device
- Not secure for production use
- Random passwords are generated but stored locally

**For production use, implement:**
- Real authentication (Firebase, Supabase, etc.)
- Backend validation
- Secure data storage
- Proper encryption

## 🎨 Customization

### Change App Colors

Edit `lib/main.dart`:
```dart
primaryColor: const Color(0xFF4A90E2),  // Change this color
```

### Modify Theme

Edit the `ThemeData` section in `lib/main.dart` to customize fonts, colors, and styles.

## 📞 Support

For issues related to:
- **Flutter**: https://flutter.dev/docs/resources/faq
- **Provider**: https://pub.dev/packages/provider
- **fl_chart**: https://pub.dev/packages/fl_chart

## 🎉 You're Ready!

Your Smart BMI Assistant app is now set up and ready to use. Run `flutter run` to start the application!

### Quick Start:
1. Run `flutter pub get`
2. Run `flutter run`
3. Sign up with your name and profile details
4. Start tracking your BMI!
