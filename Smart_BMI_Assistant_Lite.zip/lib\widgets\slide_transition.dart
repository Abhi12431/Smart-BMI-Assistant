import 'package:flutter/material.dart';

class SlidePageRoute extends PageRouteBuilder {
  final Widget child;
  final SlideDirection direction;

  SlidePageRoute({
    required this.child,
    this.direction = SlideDirection.right,
  }) : super(
          pageBuilder: (context, animation, secondaryAnimation) => child,
          transitionDuration: Duration(milliseconds: 300),
          reverseTransitionDuration: Duration(milliseconds: 300),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            Offset begin;
            switch (direction) {
              case SlideDirection.right:
                begin = Offset(1.0, 0.0);
                break;
              case SlideDirection.left:
                begin = Offset(-1.0, 0.0);
                break;
              case SlideDirection.up:
                begin = Offset(0.0, 1.0);
                break;
              case SlideDirection.down:
                begin = Offset(0.0, -1.0);
                break;
            }
            
            final end = Offset.zero;
            final curve = Curves.easeInOut;
            
            var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
            
            return SlideTransition(
              position: animation.drive(tween),
              child: FadeTransition(
                opacity: animation,
                child: child,
              ),
            );
          },
        );
}

enum SlideDirection {
  right,
  left,
  up,
  down,
}
