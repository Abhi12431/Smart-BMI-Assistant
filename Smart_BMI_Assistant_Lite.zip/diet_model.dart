import 'package:hive/hive.dart';

part 'diet_model.g.dart';

@HiveType(typeId: 2)
class DietModel extends HiveObject {
  @HiveField(0)
  String type; // Weight Loss / Gain / Maintenance

  @HiveField(1)
  String bmiCategory;

  @HiveField(2)
  List<MealModel> meals;

  @HiveField(3)
  String waterIntake;

  @HiveField(4)
  String exerciseTip;

  @HiveField(5)
  List<String> suggestions;

  @HiveField(6)
  int dailyCalories;

  @HiveField(7)
  DateTime createdAt;

  DietModel({
    required this.type,
    required this.bmiCategory,
    required this.meals,
    required this.waterIntake,
    required this.exerciseTip,
    required this.suggestions,
    required this.dailyCalories,
    required this.createdAt,
  });

  DietModel copyWith({
    String? type,
    String? bmiCategory,
    List<MealModel>? meals,
    String? waterIntake,
    String? exerciseTip,
    List<String>? suggestions,
    int? dailyCalories,
    DateTime? createdAt,
  }) {
    return DietModel(
      type: type ?? this.type,
      bmiCategory: bmiCategory ?? this.bmiCategory,
      meals: meals ?? this.meals,
      waterIntake: waterIntake ?? this.waterIntake,
      exerciseTip: exerciseTip ?? this.exerciseTip,
      suggestions: suggestions ?? this.suggestions,
      dailyCalories: dailyCalories ?? this.dailyCalories,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

@HiveType(typeId: 3)
class MealModel extends HiveObject {
  @HiveField(0)
  String name;

  @HiveField(1)
  String time;

  @HiveField(2)
  int calories;

  @HiveField(3)
  List<String> items;

  MealModel({
    required this.name,
    required this.time,
    required this.calories,
    required this.items,
  });

  MealModel copyWith({
    String? name,
    String? time,
    int? calories,
    List<String>? items,
  }) {
    return MealModel(
      name: name ?? this.name,
      time: time ?? this.time,
      calories: calories ?? this.calories,
      items: items ?? this.items,
    );
  }
}
