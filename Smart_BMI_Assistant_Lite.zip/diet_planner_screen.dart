import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/bmi_result.dart';
import '../models/diet_model.dart';
import '../services/hive_service.dart';

class DietPlannerScreen extends StatefulWidget {
  final String bmiCategory;
  
  const DietPlannerScreen({super.key, required this.bmiCategory});

  @override
  State<DietPlannerScreen> createState() => _DietPlannerScreenState();
}

class _DietPlannerScreenState extends State<DietPlannerScreen>
    with TickerProviderStateMixin {
  late AnimationController _headerAnimationController;
  late AnimationController _cardAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _cardScaleAnimation;
  late List<AnimationController> _mealCardControllers;
  late List<Animation<double>> _mealCardAnimations;
  
  DietModel? _dietPlan;
  String _selectedDay = 'Monday';

  @override
  void initState() {
    super.initState();
    _loadDietPlan();
    
    _headerAnimationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _cardAnimationController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _headerSlideAnimation = CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    );
    
    _cardScaleAnimation = CurvedAnimation(
      parent: _cardAnimationController,
      curve: Curves.elasticOut,
    );
    
    // Initialize meal card animations
    _mealCardControllers = [];
    _mealCardAnimations = [];
    
    _headerAnimationController.forward();
    Future.delayed(Duration(milliseconds: 300), () {
      _cardAnimationController.forward();
    });
  }

  Future<void> _loadDietPlan() async {
    // Try to load saved diet plan from Hive
    final savedDiet = HiveService.getCurrentDietPlan();
    
    if (savedDiet != null && savedDiet.bmiCategory == widget.bmiCategory) {
      setState(() {
        _dietPlan = savedDiet;
      });
    } else {
      // Generate new diet plan based on BMI category
      final newDiet = _generateDietPlan(widget.bmiCategory);
      await HiveService.saveDietPlan(newDiet);
      setState(() {
        _dietPlan = newDiet;
      });
    }
    
    // Initialize meal card animations after diet plan is loaded
    _initializeMealAnimations();
  }

  DietModel _generateDietPlan(String bmiCategory) {
    List<MealModel> meals = [];
    String waterIntake = '';
    String exerciseTip = '';
    List<String> suggestions = [];
    int dailyCalories = 2000;

    switch (bmiCategory.toLowerCase()) {
      case 'underweight':
        meals = [
          MealModel(
            name: 'Breakfast',
            time: '7:00 AM',
            calories: 450,
            items: ['Oatmeal with nuts', 'Banana', 'Whole milk', 'Honey'],
          ),
          MealModel(
            name: 'Lunch',
            time: '12:30 PM',
            calories: 650,
            items: ['Chicken breast', 'Rice', 'Vegetables', 'Olive oil'],
          ),
          MealModel(
            name: 'Dinner',
            time: '7:00 PM',
            calories: 600,
            items: ['Salmon', 'Sweet potato', 'Avocado', 'Quinoa'],
          ),
        ];
        waterIntake = '3-4 liters per day';
        exerciseTip = 'Focus on strength training to build muscle mass';
        suggestions = [
          'Eat protein-rich foods to build muscle',
          'Include healthy fats in your diet',
          'Eat 5-6 small meals throughout the day',
          'Avoid skipping meals',
        ];
        dailyCalories = 2500;
        break;
      case 'normal':
        meals = [
          MealModel(
            name: 'Breakfast',
            time: '7:00 AM',
            calories: 400,
            items: ['Eggs', 'Whole grain toast', 'Fruit', 'Coffee/Tea'],
          ),
          MealModel(
            name: 'Lunch',
            time: '12:30 PM',
            calories: 550,
            items: ['Grilled chicken', 'Mixed greens', 'Brown rice', 'Light dressing'],
          ),
          MealModel(
            name: 'Dinner',
            time: '7:00 PM',
            calories: 500,
            items: ['Fish', 'Steamed vegetables', 'Whole grain pasta', 'Olive oil'],
          ),
        ];
        waterIntake = '2-3 liters per day';
        exerciseTip = 'Maintain balanced cardio and strength training';
        suggestions = [
          'Maintain a balanced diet',
          'Stay hydrated throughout the day',
          'Exercise regularly',
          'Get adequate sleep',
        ];
        dailyCalories = 2000;
        break;
      case 'overweight':
        meals = [
          MealModel(
            name: 'Breakfast',
            time: '7:00 AM',
            calories: 350,
            items: ['Greek yogurt', 'Berries', 'Almonds', 'Green tea'],
          ),
          MealModel(
            name: 'Lunch',
            time: '12:30 PM',
            calories: 450,
            items: ['Grilled fish', 'Large salad', 'Lentil soup', 'Minimal oil'],
          ),
          MealModel(
            name: 'Dinner',
            time: '7:00 PM',
            calories: 400,
            items: ['Lean protein', 'Steamed vegetables', 'Small portion of rice', 'Herbs'],
          ),
        ];
        waterIntake = '3-4 liters per day';
        exerciseTip = 'Focus on cardio exercises for weight loss';
        suggestions = [
          'Reduce calorie intake gradually',
          'Increase physical activity',
          'Avoid processed foods',
          'Eat more fiber-rich foods',
        ];
        dailyCalories = 1500;
        break;
      default:
        meals = [
          MealModel(
            name: 'Breakfast',
            time: '7:00 AM',
            calories: 400,
            items: ['Eggs', 'Whole grain toast', 'Fruit'],
          ),
          MealModel(
            name: 'Lunch',
            time: '12:30 PM',
            calories: 550,
            items: ['Grilled chicken', 'Mixed greens', 'Brown rice'],
          ),
          MealModel(
            name: 'Dinner',
            time: '7:00 PM',
            calories: 500,
            items: ['Fish', 'Steamed vegetables', 'Whole grain pasta'],
          ),
        ];
        waterIntake = '2-3 liters per day';
        exerciseTip = 'Maintain balanced cardio and strength training';
        suggestions = [
          'Maintain a balanced diet',
          'Stay hydrated throughout the day',
          'Exercise regularly',
        ];
        dailyCalories = 2000;
    }

    return DietModel(
      type: bmiCategory,
      bmiCategory: bmiCategory,
      meals: meals,
      waterIntake: waterIntake,
      exerciseTip: exerciseTip,
      suggestions: suggestions,
      dailyCalories: dailyCalories,
      createdAt: DateTime.now(),
    );
  }

  void _initializeMealAnimations() {
    _mealCardControllers = [];
    _mealCardAnimations = [];
    if (_dietPlan != null) {
      for (int i = 0; i < _dietPlan!.meals.length; i++) {
        final controller = AnimationController(
          duration: Duration(milliseconds: 600),
          vsync: this,
        );
        final animation = CurvedAnimation(
          parent: controller,
          curve: Curves.easeOutBack,
        );
        _mealCardControllers.add(controller);
        _mealCardAnimations.add(animation);
      }
      
      // Stagger meal card animations
      for (int i = 0; i < _mealCardControllers.length; i++) {
        Future.delayed(Duration(milliseconds: 400 + (i * 150)), () {
          _mealCardControllers[i].forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _headerAnimationController.dispose();
    _cardAnimationController.dispose();
    for (final controller in _mealCardControllers) {
      controller.dispose();
    }
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'Diet Planner',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF4A90E2),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF4A90E2),
                Color(0xFF50C878),
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: _buildMealPlans(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return SlideTransition(
      position: _headerSlideAnimation.drive(
        Tween(begin: Offset(0, -1), end: Offset.zero),
      ),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF4A90E2), Color(0xFF50C878)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(30),
            bottomRight: Radius.circular(30),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'BMI Category: ${widget.bmiCategory}',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Personalized Meal Plan',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDaySelector() {
    final days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 5,
          ),
        ],
      ),
      height: 70,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: days.length,
        itemBuilder: (context, index) {
          final isSelected = _selectedDay == days[index];
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 6),
            child: InkWell(
              onTap: () {
                setState(() {
                  _selectedDay = days[index];
                });
              },
              borderRadius: BorderRadius.circular(30),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: isSelected ? Color(0xFF4A90E2) : Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Text(
                  days[index].substring(0, 3),
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.black87,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMealPlans() {
    if (_dietPlan == null) {
      return Center(child: CircularProgressIndicator());
    }
    
    return Column(
      children: [
        _buildDaySelector(),
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(vertical: 8),
            itemCount: _dietPlan!.meals.length + 1,
            itemBuilder: (context, index) {
              if (index == _dietPlan!.meals.length) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 16),
                  child: _buildSuggestionsCard(),
                );
              }
              final meal = _dietPlan!.meals[index];
              return _buildAnimatedMealCard(meal, index);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAnimatedMealCard(MealModel meal, int index) {
    if (index >= _mealCardAnimations.length) {
      return _buildMealCard(meal);
    }
    
    return ScaleTransition(
      scale: _mealCardAnimations[index],
      child: FadeTransition(
        opacity: _mealCardAnimations[index],
        child: _buildMealCard(meal),
      ),
    );
  }

  Widget _buildMealCard(MealModel meal) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Color(0xFF4A90E2).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  _getMealIcon(meal.name),
                  color: Color(0xFF4A90E2),
                  size: 24,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      meal.name,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2C3E50),
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      meal.time,
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF7F8C8D),
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                '${meal.calories} cal',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF4A90E2),
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(width: 8),
              Icon(
                Icons.keyboard_arrow_down,
                color: Color(0xFF7F8C8D),
              ),
            ],
          ),
          ExpansionTile(
            title: SizedBox.shrink(),
            tilePadding: EdgeInsets.zero,
            childrenPadding: EdgeInsets.only(top: 12),
            collapsedIconColor: Color(0xFF7F8C8D),
            iconColor: Color(0xFF4A90E2),
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Food Items:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2C3E50),
                    ),
                  ),
                  SizedBox(height: 12),
                  ...meal.items.map((item) => Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: Color(0xFF50C878),
                            shape: BoxShape.circle,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            item,
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF34495E),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  IconData _getMealIcon(String mealName) {
    switch (mealName.toLowerCase()) {
      case 'breakfast':
        return Icons.free_breakfast;
      case 'lunch':
        return Icons.lunch_dining;
      case 'dinner':
        return Icons.dinner_dining;
      case 'snacks':
        return Icons.cookie;
      default:
        return Icons.restaurant;
    }
  }

  Widget _buildSuggestionsCard() {
    if (_dietPlan == null) return SizedBox.shrink();
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Color(0xFF4A90E2).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.lightbulb, color: Color(0xFF4A90E2), size: 24),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Health Tips',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2C3E50),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          _buildTipRow('💧 Water Intake', _dietPlan!.waterIntake),
          SizedBox(height: 12),
          _buildTipRow('🏃 Exercise', _dietPlan!.exerciseTip),
          SizedBox(height: 16),
          Text(
            'Lifestyle Suggestions:',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2C3E50),
            ),
          ),
          SizedBox(height: 12),
          ..._dietPlan!.suggestions.map((suggestion) => Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '• ',
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF4A90E2),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text(
                    suggestion,
                    style: TextStyle(
                      fontSize: 14,
                      color: Color(0xFF34495E),
                    ),
                  ),
                ),
              ],
            ),
          )),
          SizedBox(height: 8),
          Text(
            'Daily Calories: ${_dietPlan!.dailyCalories}',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF50C878),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTipRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFF2C3E50),
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF7F8C8D),
            ),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }
}
