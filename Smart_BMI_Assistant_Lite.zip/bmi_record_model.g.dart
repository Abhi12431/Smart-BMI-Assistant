// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bmi_record_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class BmiRecordModelAdapter extends TypeAdapter<BmiRecordModel> {
  @override
  final int typeId = 1;

  @override
  BmiRecordModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return BmiRecordModel(
      bmi: fields[0] as double,
      weight: fields[1] as double,
      height: fields[2] as double,
      age: fields[3] as int,
      gender: fields[4] as String,
      category: fields[5] as String,
      date: fields[6] as DateTime,
      suggestion: fields[7] as String,
    );
  }

  @override
  void write(BinaryWriter writer, BmiRecordModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.bmi)
      ..writeByte(1)
      ..write(obj.weight)
      ..writeByte(2)
      ..write(obj.height)
      ..writeByte(3)
      ..write(obj.age)
      ..writeByte(4)
      ..write(obj.gender)
      ..writeByte(5)
      ..write(obj.category)
      ..writeByte(6)
      ..write(obj.date)
      ..writeByte(7)
      ..write(obj.suggestion);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BmiRecordModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
