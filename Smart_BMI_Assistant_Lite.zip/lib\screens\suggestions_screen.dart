import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/bmi_result.dart';
import '../models/bmi_record_model.dart';
import '../services/hive_service.dart';
import 'diet_planner_screen.dart';

class SuggestionsScreen extends StatefulWidget {
  const SuggestionsScreen({super.key});

  @override
  State<SuggestionsScreen> createState() => _SuggestionsScreenState();
}

class _SuggestionsScreenState extends State<SuggestionsScreen>
    with TickerProviderStateMixin {
  BMIResult? _latestResult;
  bool _isLoading = true;
  late AnimationController _cardAnimationController;
  late AnimationController _fadeAnimationController;
  late Animation<double> _cardScaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _cardAnimationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimationController = AnimationController(
      duration: Duration(milliseconds: 1200),
      vsync: this,
    );
    
    _cardScaleAnimation = CurvedAnimation(
      parent: _cardAnimationController,
      curve: Curves.elasticOut,
    );
    
    _fadeAnimation = CurvedAnimation(
      parent: _fadeAnimationController,
      curve: Curves.easeInOut,
    );
    
    _loadLatestResult();
  }

  @override
  void dispose() {
    _cardAnimationController.dispose();
    _fadeAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadLatestResult() async {
    final latestBmiRecord = HiveService.getLatestBmiRecord();
    
    if (latestBmiRecord != null) {
      final bmiResult = BMIResult(
        bmi: latestBmiRecord.bmi,
        weight: latestBmiRecord.weight,
        height: latestBmiRecord.height,
        age: latestBmiRecord.age,
        gender: latestBmiRecord.gender,
        category: latestBmiRecord.category,
        date: latestBmiRecord.date,
        suggestion: latestBmiRecord.suggestion,
      );
      setState(() {
        _latestResult = bmiResult;
        _isLoading = false;
      });
      _cardAnimationController.forward();
      _fadeAnimationController.forward();
    } else {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'Health Suggestions',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF4A90E2),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF4A90E2),
                Color(0xFF50C878),
              ],
            ),
          ),
        ),
      ),
      body: _latestResult == null
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    size: 64,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'No BMI data available',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Calculate your BMI first to get suggestions',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCurrentBMICard(),
                  SizedBox(height: 24),
                  _buildGeneralTips(),
                  SizedBox(height: 24),
                  _buildDietSuggestions(),
                  SizedBox(height: 24),
                  _buildExerciseSuggestions(),
                  SizedBox(height: 24),
                  _buildLifestyleTips(),
                  SizedBox(height: 24),
                  _buildDietPlannerButton(),
                ],
              ),
            ),
    );
  }

  Widget _buildCurrentBMICard() {
    return ScaleTransition(
      scale: _cardScaleAnimation,
      child: Card(
        elevation: 4,
        shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.fitness_center,
                    color: Color(0xFF4A90E2),
                  ),
                  SizedBox(width: 8),
                  Text(
                    'Your Current BMI',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF4A90E2),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: BMIResult.getCategoryColor(_latestResult!.category),
                    child: Text(
                      _latestResult!.bmi.toStringAsFixed(1),
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _latestResult!.category,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: BMIResult.getCategoryColor(_latestResult!.category),
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Calculated on ${DateFormat('MMM dd, yyyy').format(_latestResult!.date)}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGeneralTips() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 50 * (1 - value)),
          child: Opacity(
            opacity: value,
            child: Card(
              elevation: 4,
              shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Color(0xFF4A90E2).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.lightbulb,
                            color: Color(0xFF4A90E2),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Personalized Recommendations',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF4A90E2),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    Text(_latestResult!.suggestion),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildDietSuggestions() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 50 * (1 - value)),
          child: Opacity(
            opacity: value,
            child: Card(
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.restaurant,
                            color: Colors.green,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Dietary Guidelines',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    _getDietSuggestions(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildExerciseSuggestions() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 1000),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 50 * (1 - value)),
          child: Opacity(
            opacity: value,
            child: Card(
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.orange.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.fitness_center,
                            color: Colors.orange,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Exercise Recommendations',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    _getExerciseSuggestions(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildLifestyleTips() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 1200),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 50 * (1 - value)),
          child: Opacity(
            opacity: value,
            child: Card(
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.purple.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            Icons.favorite,
                            color: Colors.purple,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Lifestyle Tips',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12),
                    _getLifestyleTips(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _getDietSuggestions() {
    final category = _latestResult!.category;
    List<String> suggestions = [];

    switch (category) {
      case 'Severely Underweight':
      case 'Underweight':
        suggestions = [
          '• Eat 5-6 small meals throughout the day',
          '• Include protein in every meal (eggs, meat, legumes)',
          '• Add healthy fats (avocado, nuts, olive oil)',
          '• Choose calorie-dense foods',
          '• Drink milk and fruit juices between meals',
        ];
        break;
      case 'Normal Weight':
        suggestions = [
          '• Maintain balanced diet with all food groups',
          '• Eat plenty of fruits and vegetables',
          '• Choose whole grains over refined grains',
          '• Limit processed foods and added sugars',
          '• Stay hydrated with 8-10 glasses of water daily',
        ];
        break;
      case 'Overweight':
      case 'Obese Class I':
      case 'Obese Class II':
      case 'Obese Class III':
        suggestions = [
          '• Create a calorie deficit of 500-750 calories daily',
          '• Focus on high-fiber foods for satiety',
          '• Replace sugary drinks with water',
          '• Control portion sizes',
          '• Choose lean proteins and plenty of vegetables',
        ];
        break;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: suggestions.map((suggestion) => Padding(
        padding: EdgeInsets.symmetric(vertical: 2),
        child: Text(suggestion),
      )).toList(),
    );
  }

  Widget _getExerciseSuggestions() {
    final category = _latestResult!.category;
    List<String> suggestions = [];

    switch (category) {
      case 'Severely Underweight':
      case 'Underweight':
        suggestions = [
          '• Focus on strength training to build muscle',
          '• Start with bodyweight exercises',
          '• Limit excessive cardio that burns calories',
          '• Aim for 3-4 strength sessions per week',
          '• Include compound movements (squats, deadlifts)',
        ];
        break;
      case 'Normal Weight':
        suggestions = [
          '• 150 minutes of moderate aerobic activity weekly',
          '• 2 strength training sessions per week',
          '• Mix cardio and flexibility exercises',
          '• Include activities you enjoy for consistency',
          '• Consider yoga or pilates for flexibility',
        ];
        break;
      case 'Overweight':
      case 'Obese Class I':
        suggestions = [
          '• Start with low-impact exercises (walking, swimming)',
          '• Aim for 300 minutes of moderate activity weekly',
          '• Include both cardio and strength training',
          '• Gradually increase intensity and duration',
          '• Find activities that fit your lifestyle',
        ];
        break;
      case 'Obese Class II':
      case 'Obese Class III':
        suggestions = [
          '• Consult healthcare provider before starting',
          '• Begin with gentle walking (10-15 minutes daily)',
          '• Water exercises to reduce joint stress',
          '• Chair exercises for limited mobility',
          '• Focus on consistency over intensity',
        ];
        break;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: suggestions.map((suggestion) => Padding(
        padding: EdgeInsets.symmetric(vertical: 2),
        child: Text(suggestion),
      )).toList(),
    );
  }

  Widget _getLifestyleTips() {
    List<String> suggestions = [
      '• Aim for 7-9 hours of quality sleep nightly',
      '• Manage stress through meditation or hobbies',
      '• Monitor weight changes weekly',
      '• Schedule regular health check-ups',
      '• Stay consistent with your routine',
    ];

    if (_latestResult!.category.contains('Obese')) {
      suggestions.addAll([
        '• Monitor blood pressure regularly',
        '• Check blood sugar levels if diabetic',
        '• Consider professional nutritional guidance',
      ]);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: suggestions.map((suggestion) => Padding(
        padding: EdgeInsets.symmetric(vertical: 2),
        child: Text(suggestion),
      )).toList(),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Severely Underweight':
      case 'Underweight':
        return Icons.trending_down;
      case 'Normal Weight':
        return Icons.check_circle;
      case 'Overweight':
        return Icons.warning;
      case 'Obese Class I':
      case 'Obese Class II':
      case 'Obese Class III':
        return Icons.dangerous;
      default:
        return Icons.help;
    }
  }

  Widget _buildDietPlannerButton() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 30 * (1 - value)),
          child: Opacity(
            opacity: value,
            child: Container(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    PageRouteBuilder(
                      pageBuilder: (context, animation, secondaryAnimation) => DietPlannerScreen(bmiCategory: _latestResult!.category),
                      transitionsBuilder: (context, animation, secondaryAnimation, child) {
                        return SlideTransition(
                          position: animation.drive(
                            Tween(begin: Offset(1.0, 0.0), end: Offset.zero),
                          ),
                          child: child,
                        );
                      },
                      transitionDuration: Duration(milliseconds: 500),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF4A90E2),
                  foregroundColor: Colors.white,
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(28),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.restaurant_menu),
                    SizedBox(width: 8),
                    Text(
                      'View Diet Planner',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
