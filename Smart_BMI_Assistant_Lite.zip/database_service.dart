import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/user_profile.dart';
import '../models/bmi_result.dart';

class DatabaseService {
  static const String _keyBMIHistory = 'bmi_history';

  // Create or update user profile (local storage only)
  Future<void> upsertUserProfile(UserProfile profile) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_name', profile.name);
      await prefs.setString('user_email', profile.email);
      await prefs.setInt('user_age', profile.age);
      await prefs.setDouble('user_height', profile.height);
      await prefs.setDouble('user_weight', profile.weight);
      await prefs.setString('user_gender', profile.gender);
      await prefs.setString('user_goal', profile.goal);
    } catch (e) {
      throw Exception('Failed to save profile: $e');
    }
  }

  // Get user profile by ID (local storage only)
  Future<UserProfile?> getUserProfile(String userId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final name = prefs.getString('user_name');
      
      if (name == null) return null;

      return UserProfile(
        id: userId,
        name: name,
        email: prefs.getString('user_email') ?? '$name@local.app',
        age: prefs.getInt('user_age') ?? 25,
        height: prefs.getDouble('user_height') ?? 170.0,
        weight: prefs.getDouble('user_weight') ?? 70.0,
        gender: prefs.getString('user_gender') ?? 'Male',
        goal: prefs.getString('user_goal') ?? 'Maintain Weight',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
    } catch (e) {
      return null;
    }
  }

  // Save BMI result (local storage only)
  Future<void> saveBMIResult(BMIResult result, String userId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final history = prefs.getStringList(_keyBMIHistory) ?? [];
      
      final resultJson = result.toJson();
      resultJson['user_id'] = userId;
      
      history.add(jsonEncode(resultJson));
      
      // Keep only last 50 results
      if (history.length > 50) {
        history.removeAt(0);
      }
      
      await prefs.setStringList(_keyBMIHistory, history);
    } catch (e) {
      throw Exception('Failed to save BMI result: $e');
    }
  }

  // Get BMI history for user (local storage only)
  Future<List<BMIResult>> getBMIHistory(String userId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final history = prefs.getStringList(_keyBMIHistory) ?? [];
      
      return history
          .map((json) => BMIResult.fromJson(jsonDecode(json)))
          .toList()
        ..sort((a, b) => b.date.compareTo(a.date));
    } catch (e) {
      return [];
    }
  }

  // Delete BMI result (local storage only)
  Future<void> deleteBMIResult(String resultId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final history = prefs.getStringList(_keyBMIHistory) ?? [];
      
      final filteredHistory = history.where((json) {
        final result = BMIResult.fromJson(jsonDecode(json));
        return result.id != resultId;
      }).toList();
      
      await prefs.setStringList(_keyBMIHistory, filteredHistory);
    } catch (e) {
      throw Exception('Failed to delete BMI result: $e');
    }
  }

  // Get BMI statistics (local storage only)
  Future<Map<String, dynamic>> getBMIStatistics(String userId) async {
    try {
      final history = await getBMIHistory(userId);
      if (history.isEmpty) {
        return {
          'average': 0.0,
          'min': 0.0,
          'max': 0.0,
          'count': 0,
        };
      }

      final bmiValues = history.map((r) => r.bmi).toList();
      return {
        'average': bmiValues.reduce((a, b) => a + b) / bmiValues.length,
        'min': bmiValues.reduce((a, b) => a < b ? a : b),
        'max': bmiValues.reduce((a, b) => a > b ? a : b),
        'count': history.length,
      };
    } catch (e) {
      return {
        'average': 0.0,
        'min': 0.0,
        'max': 0.0,
        'count': 0,
      };
    }
  }
}
