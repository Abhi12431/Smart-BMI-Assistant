import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/bmi_result.dart';

class DietSuggestionScreen extends StatefulWidget {
  final BMIResult? bmiData;
  
  const DietSuggestionScreen({super.key, this.bmiData});

  @override
  State<DietSuggestionScreen> createState() => _DietSuggestionScreenState();
}

class _DietSuggestionScreenState extends State<DietSuggestionScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  final _ageController = TextEditingController();
  String _selectedGender = 'Male';
  String _selectedActivity = 'Moderate';
  String _selectedDiet = 'Omnivore';
  String _selectedGoal = 'Maintain Weight';
  List<String> _selectedAllergies = [];
  
  late AnimationController _headerAnimationController;
  late AnimationController _formAnimationController;
  late Animation<double> _headerSlideAnimation;
  late Animation<double> _formFadeAnimation;

  @override
  void initState() {
    super.initState();
    
    // Pre-fill form with BMI data if available
    if (widget.bmiData != null) {
      _heightController.text = widget.bmiData!.height.toString();
      _weightController.text = widget.bmiData!.weight.toString();
      _ageController.text = widget.bmiData!.age.toString();
      _selectedGender = widget.bmiData!.gender;
      
      // Set default goal based on BMI category
      if (widget.bmiData!.bmi < 18.5) {
        _selectedGoal = 'Gain Weight';
      } else if (widget.bmiData!.bmi >= 25) {
        _selectedGoal = 'Lose Weight';
      } else {
        _selectedGoal = 'Maintain Weight';
      }
    }
    
    _headerAnimationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _formAnimationController = AnimationController(
      duration: Duration(milliseconds: 1200),
      vsync: this,
    );
    
    _headerSlideAnimation = CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeOutBack,
    );
    
    _formFadeAnimation = CurvedAnimation(
      parent: _formAnimationController,
      curve: Curves.easeInOut,
    );
    
    _headerAnimationController.forward();
    Future.delayed(Duration(milliseconds: 300), () {
      _formAnimationController.forward();
    });
  }

  @override
  void dispose() {
    _heightController.dispose();
    _weightController.dispose();
    _ageController.dispose();
    _headerAnimationController.dispose();
    _formAnimationController.dispose();
    super.dispose();
  }

  void _generateDietPlan() {
    if (_formKey.currentState!.validate()) {
      final height = double.parse(_heightController.text);
      final weight = double.parse(_weightController.text);
      final age = int.parse(_ageController.text);
      
      final heightInMeters = height / 100;
      final bmi = weight / (heightInMeters * heightInMeters);
      
      final category = BMIResult.getBMICategory(bmi);
      
      final dietPlan = DietPlan(
        height: height,
        weight: weight,
        age: age,
        gender: _selectedGender,
        activity: _selectedActivity,
        diet: _selectedDiet,
        goal: _selectedGoal,
        allergies: _selectedAllergies,
        bmi: bmi,
        category: category,
      );

      Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) => DietPlanResultScreen(dietPlan: dietPlan),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return SlideTransition(
              position: animation.drive(
                Tween(begin: Offset(1.0, 0.0), end: Offset.zero),
              ),
              child: child,
            );
          },
          transitionDuration: Duration(milliseconds: 500),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            backgroundColor: Color(0xFF4A90E2),
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Personalized Diet Plan',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF4A90E2),
                      Color(0xFF50C878),
                    ],
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      right: -50,
                      top: -50,
                      child: Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.1),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 20,
                      top: 60,
                      child: Icon(
                        Icons.restaurant_menu,
                        size: 80,
                        color: Colors.white.withOpacity(0.3),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: FadeTransition(
              opacity: _formFadeAnimation,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSectionTitle('Basic Information'),
                      _buildBasicInfoCard(),
                      SizedBox(height: 24),
                      _buildSectionTitle('Lifestyle & Preferences'),
                      _buildLifestyleCard(),
                      SizedBox(height: 24),
                      _buildSectionTitle('Dietary Preferences'),
                      _buildDietaryCard(),
                      SizedBox(height: 24),
                      _buildSectionTitle('Health Goals'),
                      _buildGoalsCard(),
                      SizedBox(height: 32),
                      _buildGenerateButton(),
                      SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Color(0xFF4A90E2),
        ),
      ),
    );
  }

  Widget _buildBasicInfoCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _buildInputField(_heightController, 'Height (cm)', Icons.height)),
                SizedBox(width: 16),
                Expanded(child: _buildInputField(_weightController, 'Weight (kg)', Icons.monitor_weight)),
              ],
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: _buildInputField(_ageController, 'Age', Icons.cake)),
                SizedBox(width: 16),
                Expanded(child: _buildGenderDropdown()),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField(TextEditingController controller, String label, IconData icon) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Color(0xFF4A90E2)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Color(0xFFE0E0E0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Color(0xFF4A90E2)),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Required';
        }
        final numValue = double.tryParse(value);
        if (numValue == null || numValue <= 0) {
          return 'Invalid';
        }
        return null;
      },
    );
  }

  Widget _buildGenderDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedGender,
      decoration: InputDecoration(
        labelText: 'Gender',
        prefixIcon: Icon(Icons.person, color: Color(0xFF4A90E2)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Color(0xFFE0E0E0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Color(0xFF4A90E2)),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      items: ['Male', 'Female', 'Other'].map((gender) {
        return DropdownMenuItem(value: gender, child: Text(gender));
      }).toList(),
      onChanged: (value) {
        setState(() {
          _selectedGender = value!;
        });
      },
    );
  }

  Widget _buildLifestyleCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Activity Level',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2C3E50),
              ),
            ),
            SizedBox(height: 12),
            _buildActivitySelector(),
          ],
        ),
      ),
    );
  }

  Widget _buildActivitySelector() {
    final activities = [
      {'label': 'Sedentary', 'icon': Icons.chair, 'desc': 'Little or no exercise'},
      {'label': 'Light', 'icon': Icons.directions_walk, 'desc': 'Light exercise 1-3 days/week'},
      {'label': 'Moderate', 'icon': Icons.directions_run, 'desc': 'Moderate exercise 3-5 days/week'},
      {'label': 'Active', 'icon': Icons.fitness_center, 'desc': 'Hard exercise 6-7 days/week'},
      {'label': 'Very Active', 'icon': Icons.sports, 'desc': 'Very hard exercise & physical job'},
    ];

    return Column(
      children: activities.map((activity) {
        final isSelected = _selectedActivity == activity['label'] as String;
        return Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () {
              setState(() {
                _selectedActivity = activity['label'] as String;
              });
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(
                  color: isSelected ? Color(0xFF4A90E2) : Color(0xFFE0E0E0),
                ),
                borderRadius: BorderRadius.circular(12),
                color: isSelected ? Color(0xFF4A90E2).withOpacity(0.1) : Colors.white,
              ),
              child: Row(
                children: [
                  Icon(
                    activity['icon'] as IconData,
                    color: isSelected ? Color(0xFF4A90E2) : Colors.grey,
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          activity['label'] as String,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: isSelected ? Color(0xFF4A90E2) : Colors.black87,
                          ),
                        ),
                        Text(
                          activity['desc'] as String,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isSelected)
                    Icon(Icons.check_circle, color: Color(0xFF4A90E2)),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildDietaryCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Diet Type',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2C3E50),
              ),
            ),
            SizedBox(height: 12),
            _buildDietSelector(),
            SizedBox(height: 20),
            Text(
              'Food Allergies',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2C3E50),
              ),
            ),
            SizedBox(height: 12),
            _buildAllergySelector(),
          ],
        ),
      ),
    );
  }

  Widget _buildDietSelector() {
    final diets = ['Omnivore', 'Vegetarian', 'Vegan', 'Keto', 'Paleo', 'Mediterranean'];
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: diets.map((diet) {
        final isSelected = _selectedDiet == diet;
        return InkWell(
          onTap: () {
            setState(() {
              _selectedDiet = diet;
            });
          },
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? Color(0xFF4A90E2) : Colors.grey.shade200,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              diet,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black87,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildAllergySelector() {
    final allergies = ['Dairy', 'Gluten', 'Nuts', 'Soy', 'Eggs', 'Shellfish'];
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: allergies.map((allergy) {
        final isSelected = _selectedAllergies.contains(allergy);
        return InkWell(
          onTap: () {
            setState(() {
              if (isSelected) {
                _selectedAllergies.remove(allergy);
              } else {
                _selectedAllergies.add(allergy);
              }
            });
          },
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? Colors.red.shade100 : Colors.grey.shade200,
              borderRadius: BorderRadius.circular(20),
              border: isSelected ? Border.all(color: Colors.red.shade300) : null,
            ),
            child: Text(
              allergy,
              style: TextStyle(
                color: isSelected ? Colors.red.shade700 : Colors.black87,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildGoalsCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Primary Goal',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF2C3E50),
              ),
            ),
            SizedBox(height: 12),
            _buildGoalSelector(),
          ],
        ),
      ),
    );
  }

  Widget _buildGoalSelector() {
    final goals = [
      {'label': 'Lose Weight', 'icon': Icons.trending_down},
      {'label': 'Maintain Weight', 'icon': Icons.equalizer},
      {'label': 'Gain Weight', 'icon': Icons.trending_up},
      {'label': 'Build Muscle', 'icon': Icons.fitness_center},
    ];

    return Column(
      children: goals.map((goal) {
        final isSelected = _selectedGoal == goal['label'] as String;
        return Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () {
              setState(() {
                _selectedGoal = goal['label'] as String;
              });
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(
                  color: isSelected ? Color(0xFF4A90E2) : Color(0xFFE0E0E0),
                ),
                borderRadius: BorderRadius.circular(12),
                color: isSelected ? Color(0xFF4A90E2).withOpacity(0.1) : Colors.white,
              ),
              child: Row(
                children: [
                  Icon(
                    goal['icon'] as IconData,
                    color: isSelected ? Color(0xFF4A90E2) : Colors.grey,
                  ),
                  SizedBox(width: 12),
                  Text(
                    goal['label'] as String,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: isSelected ? Color(0xFF4A90E2) : Colors.black87,
                    ),
                  ),
                  Spacer(),
                  if (isSelected)
                    Icon(Icons.check_circle, color: Color(0xFF4A90E2)),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildGenerateButton() {
    return Container(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _generateDietPlan,
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0xFF4A90E2),
          foregroundColor: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.restaurant_menu, size: 24),
            SizedBox(width: 12),
            Text(
              'Generate Personalized Diet Plan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DietPlan {
  final double height;
  final double weight;
  final int age;
  final String gender;
  final String activity;
  final String diet;
  final String goal;
  final List<String> allergies;
  final double bmi;
  final String category;

  DietPlan({
    required this.height,
    required this.weight,
    required this.age,
    required this.gender,
    required this.activity,
    required this.diet,
    required this.goal,
    required this.allergies,
    required this.bmi,
    required this.category,
  });
}

class DietPlanResultScreen extends StatelessWidget {
  final DietPlan dietPlan;

  const DietPlanResultScreen({super.key, required this.dietPlan});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'Your Personalized Diet Plan',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF4A90E2),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF4A90E2),
                Color(0xFF50C878),
              ],
            ),
          ),
        ),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSummaryCard(),
            SizedBox(height: 24),
            _buildDailyCaloriesCard(),
            SizedBox(height: 24),
            _buildMealPlanCard(),
            SizedBox(height: 24),
            _buildRecommendationsCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Profile Summary',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4A90E2),
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Color(0xFF4A90E2).withOpacity(0.1),
                  child: Icon(Icons.person, color: Color(0xFF4A90E2)),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'BMI: ${dietPlan.bmi.toStringAsFixed(1)}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        dietPlan.category,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      Text(
                        'Goal: ${dietPlan.goal}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDailyCaloriesCard() {
    final calories = _calculateDailyCalories();
    
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Daily Calorie Target',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4A90E2),
              ),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF4A90E2), Color(0xFF50C878)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Text(
                    calories.toString(),
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'calories per day',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white.withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMealPlanCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Sample Meal Plan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4A90E2),
              ),
            ),
            SizedBox(height: 16),
            _buildMealItem('Breakfast', 'Oatmeal with berries and nuts', '350 cal'),
            _buildMealItem('Lunch', 'Grilled chicken salad', '450 cal'),
            _buildMealItem('Dinner', 'Salmon with vegetables', '500 cal'),
            _buildMealItem('Snack', 'Greek yogurt with honey', '200 cal'),
          ],
        ),
      ),
    );
  }

  Widget _buildMealItem(String meal, String description, String calories) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: Color(0xFF4A90E2),
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  meal,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            calories,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Color(0xFF4A90E2),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecommendationsCard() {
    return Card(
      elevation: 4,
      shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Personalized Recommendations',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4A90E2),
              ),
            ),
            SizedBox(height: 16),
            _buildRecommendation('Drink at least 8 glasses of water daily'),
            _buildRecommendation('Include 5 servings of fruits and vegetables'),
            _buildRecommendation('Limit processed foods and added sugars'),
            _buildRecommendation('Exercise regularly for best results'),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendation(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.check_circle,
            color: Color(0xFF4A90E2),
            size: 20,
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  int _calculateDailyCalories() {
    // Basic BMR calculation using Mifflin-St Jeor Equation
    double bmr;
    if (dietPlan.gender == 'Male') {
      bmr = 10 * dietPlan.weight + 6.25 * dietPlan.height - 5 * dietPlan.age + 5;
    } else {
      bmr = 10 * dietPlan.weight + 6.25 * dietPlan.height - 5 * dietPlan.age - 161;
    }

    // Activity factor
    double activityFactor;
    switch (dietPlan.activity) {
      case 'Sedentary':
        activityFactor = 1.2;
        break;
      case 'Light':
        activityFactor = 1.375;
        break;
      case 'Moderate':
        activityFactor = 1.55;
        break;
      case 'Active':
        activityFactor = 1.725;
        break;
      case 'Very Active':
        activityFactor = 1.9;
        break;
      default:
        activityFactor = 1.55;
    }

    int tdee = (bmr * activityFactor).round();

    // Adjust based on goals
    switch (dietPlan.goal) {
      case 'Lose Weight':
        return (tdee * 0.8).round(); // 20% deficit
      case 'Gain Weight':
        return (tdee * 1.2).round(); // 20% surplus
      case 'Build Muscle':
        return (tdee * 1.1).round(); // 10% surplus
      default:
        return tdee; // Maintain
    }
  }
}
