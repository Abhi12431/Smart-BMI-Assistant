import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../models/bmi_result.dart';
import '../models/bmi_record_model.dart';
import '../providers/auth_provider.dart';
import '../services/hive_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with TickerProviderStateMixin {
  List<BMIResult> _history = [];
  bool _isLoading = true;
  
  late AnimationController _chartAnimationController;
  late AnimationController _listAnimationController;
  late Animation<double> _chartScaleAnimation;
  late Animation<double> _listSlideAnimation;

  @override
  void initState() {
    super.initState();
    
    _chartAnimationController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );
    _listAnimationController = AnimationController(
      duration: Duration(milliseconds: 1200),
      vsync: this,
    );
    
    _chartScaleAnimation = CurvedAnimation(
      parent: _chartAnimationController,
      curve: Curves.elasticOut,
    );
    
    _listSlideAnimation = CurvedAnimation(
      parent: _listAnimationController,
      curve: Curves.easeOutBack,
    );
    
    _loadHistory();
  }

  @override
  void dispose() {
    _chartAnimationController.dispose();
    _listAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final bmiRecords = HiveService.getAllBmiRecords();
    
    final history = bmiRecords.map((record) => BMIResult(
      bmi: record.bmi,
      weight: record.weight,
      height: record.height,
      age: record.age,
      gender: record.gender,
      category: record.category,
      date: record.date,
      suggestion: record.suggestion,
    )).toList();
    
    // Sort by date
    history.sort((a, b) => a.date.compareTo(b.date));
    
    setState(() {
      _history = history;
      _isLoading = false;
    });
    
    if (_history.isNotEmpty) {
      _chartAnimationController.forward();
      Future.delayed(const Duration(milliseconds: 300), () {
        _listAnimationController.forward();
      });
    }
  }

  List<FlSpot> _getChartData() {
    return _history.asMap().entries.map((entry) {
      return FlSpot(entry.key.toDouble(), entry.value.bmi);
    }).toList();
  }

  String _getBMICategory(double bmi) {
    if (bmi < 18.5) return "Underweight";
    if (bmi < 25) return "Normal";
    if (bmi < 30) return "Overweight";
    return "Obese";
  }

  Widget _buildChart() {
    final spots = _getChartData();
    
    if (spots.isEmpty) {
      return Container(
        height: 220,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 6),
          ],
        ),
        child: const Center(
          child: Text(
            'No data available',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),
        ),
      );
    }

    return Container(
      height: 220,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 6),
        ],
      ),
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true,
            drawVerticalLine: true,
            horizontalInterval: 1,
            verticalInterval: 1,
            getDrawingHorizontalLine: (value) {
              return const FlLine(
                color: Colors.grey,
                strokeWidth: 0.5,
              );
            },
            getDrawingVerticalLine: (value) {
              return const FlLine(
                color: Colors.grey,
                strokeWidth: 0.5,
              );
            },
          ),
          
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 40,
                interval: 5,
                getTitlesWidget: (value, meta) {
                  return Text(
                    value.toInt().toString(),
                    style: const TextStyle(
                      fontSize: 10,
                      color: Colors.grey,
                    ),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                interval: 1,
                getTitlesWidget: (value, meta) {
                  if (value.toInt() < _history.length && value.toInt() >= 0) {
                    final date = _history[value.toInt()].date;
                    return Text(
                      DateFormat('MM/dd').format(date),
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.grey,
                      ),
                    );
                  }
                  return const Text('');
                },
              ),
            ),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          
          borderData: FlBorderData(show: false),
          
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              gradient: const LinearGradient(
                colors: [Color(0xFF4A90E2), Color(0xFF50C878)],
              ),
              barWidth: 3,
              isStrokeCapRound: true,
              dotData: FlDotData(
                show: true,
                getDotPainter: (spot, percent, barData, index) {
                  return FlDotCirclePainter(
                    radius: 4,
                    color: const Color(0xFF4A90E2),
                    strokeWidth: 2,
                    strokeColor: Colors.white,
                  );
                },
              ),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF4A90E2).withOpacity(0.3),
                    const Color(0xFF50C878).withOpacity(0.1),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
          
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              getTooltipColor: (touchedSpot) => Colors.black87,
              tooltipRoundedRadius: 8,
              getTooltipItems: (touchedSpots) {
                return touchedSpots.map((spot) {
                  final index = spot.x.toInt();
                  if (index < _history.length) {
                    final result = _history[index];
                    return LineTooltipItem(
                      'BMI: ${result.bmi.toStringAsFixed(1)}\n'
                      'Date: ${DateFormat('MMM dd').format(result.date)}\n'
                      'Category: ${_getBMICategory(result.bmi)}',
                      const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    );
                  }
                  return null;
                }).toList();
              },
            ),
            handleBuiltInTouches: true,
          ),
          
          minY: (spots.map((s) => s.y).reduce((a, b) => a < b ? a : b) - 2).clamp(15.0, 40.0),
          maxY: (spots.map((s) => s.y).reduce((a, b) => a > b ? a : b) + 2).clamp(20.0, 45.0),
        ),
      ),
    );
  }

  Future<void> _clearHistory() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Clear History'),
        content: Text('Are you sure you want to clear all BMI history?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Clear'),
          ),
        ],
      ),
    );
    
    if (confirmed == true) {
      await HiveService.clearAllBmiRecords();
      setState(() {
        _history = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'BMI History',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF4A90E2),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF4A90E2),
                Color(0xFF50C878),
              ],
            ),
          ),
        ),
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TweenAnimationBuilder(
                    duration: Duration(milliseconds: 1000),
                    tween: Tween<double>(begin: 0.5, end: 1.0),
                    builder: (context, double value, child) {
                      return Transform.scale(
                        scale: value,
                        child: CircularProgressIndicator(
                          strokeWidth: 3,
                          backgroundColor: Colors.grey.shade300,
                          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4A90E2)),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Loading your BMI history...',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            )
          : _history.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TweenAnimationBuilder(
                        duration: Duration(milliseconds: 800),
                        tween: Tween<double>(begin: 0.5, end: 1.0),
                        builder: (context, double value, child) {
                          return Transform.scale(
                            scale: value,
                            child: Icon(
                              Icons.history,
                              size: 64,
                              color: Colors.grey,
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 16),
                      Text(
                        'No BMI history yet',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Calculate your BMI to see history here',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 10),
                      const Text(
                        "BMI Progress",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2C3E50),
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (_history.length >= 2)
                        ScaleTransition(
                          scale: _chartScaleAnimation,
                          child: _buildChart(),
                        )
                      else if (_history.isNotEmpty)
                        Container(
                          height: 220,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(color: Colors.black12, blurRadius: 6),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              'Need at least 2 records to show progress chart',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "History Details",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2C3E50),
                        ),
                      ),
                      const SizedBox(height: 16),
                      SlideTransition(
                        position: _listSlideAnimation.drive(
                          Tween(begin: const Offset(0, 0.5), end: Offset.zero),
                        ),
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _history.length,
                          itemBuilder: (context, index) {
                            final result = _history.reversed.toList()[index];
                            return TweenAnimationBuilder(
                              duration: const Duration(milliseconds: 300),
                              tween: Tween<double>(begin: 0, end: 1),
                              builder: (context, double value, child) {
                                return Transform.translate(
                                  offset: Offset(-20 * (1 - value), 0),
                                  child: Opacity(
                                    opacity: value,
                                    child: Padding(
                                      padding: const EdgeInsets.only(bottom: 12),
                                      child: Card(
                                        elevation: 4,
                                        shadowColor: const Color(0xFF4A90E2).withOpacity(0.15),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                        child: ListTile(
                                          leading: TweenAnimationBuilder(
                                            duration: const Duration(milliseconds: 500),
                                            tween: Tween<double>(begin: 0, end: 1),
                                            builder: (context, double value, child) {
                                              return Transform.scale(
                                                scale: value,
                                                child: CircleAvatar(
                                                  backgroundColor: BMIResult.getCategoryColor(result.category),
                                                  child: Text(
                                                    result.bmi.toStringAsFixed(1),
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                          title: Text(
                                            result.category,
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: BMIResult.getCategoryColor(result.category),
                                            ),
                                          ),
                                          subtitle: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                DateFormat('MMM dd, yyyy - hh:mm a').format(result.date),
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.grey,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              SizedBox(height: 4),
                                              Text(
                                                'Weight: ${result.weight}kg | Height: ${result.height}cm | Age: ${result.age}',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                          trailing: IconButton(
                                            onPressed: () {
                                              showDialog(
                                                context: context,
                                                builder: (context) => AnimatedDialog(
                                                  result: result,
                                                ),
                                              );
                                            },
                                            icon: Icon(Icons.lightbulb_outline),
                                            tooltip: 'View Suggestions',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
      floatingActionButton: _history.isNotEmpty
          ? FloatingActionButton(
              onPressed: _clearHistory,
              backgroundColor: const Color(0xFF4A90E2),
              child: const Icon(Icons.delete_forever),
              tooltip: 'Clear History',
            )
          : null,
    );
  }

  LineChartData _buildChartData() {
    final sortedHistory = List<BMIResult>.from(_history);
    sortedHistory.sort((a, b) => a.date.compareTo(b.date));
    
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: Colors.grey.withOpacity(0.3),
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: Colors.grey.withOpacity(0.3),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            getTitlesWidget: (value, meta) {
              if (value.toInt() >= 0 && value.toInt() < sortedHistory.length) {
                return Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text(
                    DateFormat('MM/dd').format(sortedHistory[value.toInt()].date),
                    style: TextStyle(fontSize: 10),
                  ),
                );
              }
              return Text('');
            },
            interval: 1,
          ),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 40,
            getTitlesWidget: (value, meta) {
              return Padding(
                padding: EdgeInsets.only(right: 8),
                child: Text(
                  value.toStringAsFixed(1),
                  style: TextStyle(fontSize: 10),
                ),
              );
            },
            interval: 5,
          ),
        ),
        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
      ),
      lineBarsData: [
        LineChartBarData(
          spots: sortedHistory.asMap().entries.map((entry) {
            return FlSpot(entry.key.toDouble(), entry.value.bmi);
          }).toList(),
          isCurved: true,
          color: Color(0xFF4A90E2),
          barWidth: 3,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: true,
            getDotPainter: (spot, percent, barData, index) {
              return FlDotCirclePainter(
                radius: 6,
                color: BMIResult.getCategoryColor(sortedHistory[index].category),
                strokeWidth: 2,
                strokeColor: Colors.white,
              );
            },
          ),
          belowBarData: BarAreaData(
            show: true,
            color: Theme.of(context).primaryColor.withOpacity(0.1),
          ),
        ),
      ],
      lineTouchData: LineTouchData(
        touchTooltipData: LineTouchTooltipData(
          getTooltipColor: (touchedSpot) => Colors.black87,
          tooltipRoundedRadius: 8,
          getTooltipItems: (touchedSpots) {
            return touchedSpots.map((spot) {
              final index = spot.x.toInt();
              if (index >= 0 && index < sortedHistory.length) {
                final result = sortedHistory[index];
                return LineTooltipItem(
                  'BMI: ${result.bmi.toStringAsFixed(1)}\n${result.category}',
                  const TextStyle(color: Colors.white, fontSize: 12),
                );
              }
              return null;
            }).toList();
          },
        ),
        handleBuiltInTouches: true,
      ),
      minX: 0,
      maxX: (sortedHistory.length - 1).toDouble(),
      minY: 10,
      maxY: 40,
    );
  }
}

class AnimatedDialog extends StatefulWidget {
  final BMIResult result;
  
  const AnimatedDialog({super.key, required this.result});

  @override
  State<AnimatedDialog> createState() => _AnimatedDialogState();
}

class _AnimatedDialogState extends State<AnimatedDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _dialogController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _dialogController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _scaleAnimation = CurvedAnimation(
      parent: _dialogController,
      curve: Curves.elasticOut,
    );
    _dialogController.forward();
  }

  @override
  void dispose() {
    _dialogController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.info,
              color: BMIResult.getCategoryColor(widget.result.category),
            ),
            SizedBox(width: 8),
            Text('BMI Details'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'BMI: ${widget.result.bmi.toStringAsFixed(1)}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: BMIResult.getCategoryColor(widget.result.category),
                ),
              ),
              SizedBox(height: 8),
              Text(
                widget.result.category,
                style: TextStyle(
                  fontSize: 16,
                  color: BMIResult.getCategoryColor(widget.result.category),
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Health Suggestions:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(widget.result.suggestion),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }
}
