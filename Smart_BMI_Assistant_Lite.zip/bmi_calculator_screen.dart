import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/bmi_result.dart';
import '../models/bmi_record_model.dart';
import '../services/database_service.dart';
import '../services/hive_service.dart';
import '../widgets/slide_transition.dart';
import '../providers/auth_provider.dart';
import 'diet_suggestion_screen.dart';

class BMICalculatorScreen extends StatefulWidget {
  const BMICalculatorScreen({super.key});

  @override
  State<BMICalculatorScreen> createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  String _userGender = 'Male';
  int _userAge = 20;
  BMIResult? _lastResult;
  
  late AnimationController _formAnimationController;
  late AnimationController _resultAnimationController;
  late Animation<double> _formSlideAnimation;
  late Animation<double> _resultScaleAnimation;
  bool _showResult = false;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _formAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _resultAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _formSlideAnimation = CurvedAnimation(
      parent: _formAnimationController,
      curve: Curves.easeOutBack,
    );
    
    _resultScaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _resultAnimationController,
      curve: Curves.elasticOut,
    ));

    _formAnimationController.forward();
  }

  Future<void> _loadUserData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final email = authProvider.userEmail;
    
    if (email != null) {
      final user = await HiveService.getUserByEmail(email);
      if (user != null) {
        setState(() {
          _userGender = user.gender;
          _userAge = user.age;
          _heightController.text = user.height.toString();
          _weightController.text = user.weight.toString();
        });
      }
    }
  }

  @override
  void dispose() {
    _heightController.dispose();
    _weightController.dispose();
    _formAnimationController.dispose();
    _resultAnimationController.dispose();
    super.dispose();
  }

  void _calculateBMI() {
    final heightText = _heightController.text.trim();
    final weightText = _weightController.text.trim();
    
    if (heightText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter your height')),
      );
      return;
    }
    
    if (weightText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter your weight')),
      );
      return;
    }
    
    final height = double.tryParse(heightText);
    final weight = double.tryParse(weightText);
    
    if (height == null || height <= 0 || height > 300) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid height (1-300 cm)')),
      );
      return;
    }
    
    if (weight == null || weight <= 0 || weight > 500) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid weight (1-500 kg)')),
      );
      return;
    }
    
    final bmi = weight / ((height / 100) * (height / 100));
    final category = BMIResult.getBMICategory(bmi);
    final suggestion = BMIResult.getHealthSuggestion(category, _userAge, _userGender);
    
    final result = BMIResult(
      bmi: bmi,
      category: category,
      suggestion: suggestion,
      height: height,
      weight: weight,
      age: _userAge,
      gender: _userGender,
      date: DateTime.now(),
    );
    
    setState(() {
      _lastResult = result;
      _showResult = true;
    });
    
    _resultAnimationController.forward();
    _saveResult(result);
  }

  Future<void> _saveResult(BMIResult result) async {
    // Save to Hive database
    final bmiRecord = BmiRecordModel(
      bmi: result.bmi,
      weight: result.weight,
      height: result.height,
      age: result.age,
      gender: result.gender,
      category: result.category,
      date: result.date,
      suggestion: result.suggestion,
    );
    await HiveService.saveBmiRecord(bmiRecord);
  }

  Widget _buildInputCard() {
    return Card(
      elevation: 4,
      shadowColor: const Color(0xFF4A90E2).withOpacity(0.15),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 10),
            // Height
            _buildInputField(
              title: "Height",
              icon: Icons.height,
              unit: "cm",
            ),
            const SizedBox(height: 12),
            // Weight
            _buildInputField(
              title: "Weight",
              icon: Icons.monitor_weight,
              unit: "kg",
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required String title,
    required IconData icon,
    required String unit,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
          ),
        ],
      ),
      child: Row(
        children: [
          // Icon
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF4A90E2).withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: const Color(0xFF4A90E2), size: 20),
          ),
          const SizedBox(width: 10),
          // Title + Input
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
                TextField(
                  controller: title == 'Height' ? _heightController : _weightController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: "Enter $title",
                    border: InputBorder.none,
                    hintStyle: const TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                    suffixText: unit,
                    suffixStyle: const TextStyle(
                      fontSize: 13,
                      color: Colors.grey,
                    ),
                  ),
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLastResultCard() {
    return FadeTransition(
      opacity: _resultScaleAnimation,
      child: ScaleTransition(
        scale: _resultScaleAnimation,
        child: Card(
          elevation: 4,
          shadowColor: Color(0xFF4A90E2).withOpacity(0.15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  'Your BMI Result',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF4A90E2),
                  ),
                ),
                SizedBox(height: 24),
                TweenAnimationBuilder<double>(
                  duration: Duration(milliseconds: 800),
                  tween: Tween(begin: 0, end: 1),
                  builder: (context, value, child) {
                    return Transform.scale(
                      scale: value,
                      child: Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              BMIResult.getCategoryColor(_lastResult!.category),
                              BMIResult.getCategoryColor(_lastResult!.category).withOpacity(0.7),
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: BMIResult.getCategoryColor(_lastResult!.category).withOpacity(0.3),
                              blurRadius: 20,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TweenAnimationBuilder<double>(
                                duration: Duration(milliseconds: 1000),
                                tween: Tween(begin: 0, end: _lastResult!.bmi),
                                builder: (context, bmiValue, child) {
                                  return Text(
                                    bmiValue.toStringAsFixed(1),
                                    style: TextStyle(
                                      fontSize: 48,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  );
                                },
                              ),
                              SizedBox(height: 8),
                              Text(
                                _lastResult!.category,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white.withOpacity(0.9),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 24),
                Text(
                  'Height: ${_lastResult!.height}cm | Weight: ${_lastResult!.weight}kg',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showResultDialog(BMIResult result) {
    showDialog(
      context: context,
      builder: (context) => AnimatedDialog(
        result: result,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F7FA),
      appBar: AppBar(
        title: Text(
          'BMI Calculator',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF4A90E2),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF4A90E2),
                Color(0xFF50C878),
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildInputCard(),
            const SizedBox(height: 24),
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _calculateBMI,
                borderRadius: BorderRadius.circular(25),
                splashColor: Colors.white.withOpacity(0.3),
                highlightColor: Colors.white.withOpacity(0.1),
                child: Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    color: const Color(0xFF4A90E2),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.calculate, size: 20, color: Colors.white),
                      SizedBox(width: 12),
                      Text(
                        'Calculate BMI',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (_showResult) ...[
              SizedBox(height: 24),
              _buildLastResultCard(),
            ],
            SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}

class AnimatedDialog extends StatefulWidget {
  final BMIResult result;
  
  const AnimatedDialog({super.key, required this.result});

  @override
  State<AnimatedDialog> createState() => _AnimatedDialogState();
}

class _AnimatedDialogState extends State<AnimatedDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _dialogController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _dialogController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _scaleAnimation = CurvedAnimation(
      parent: _dialogController,
      curve: Curves.elasticOut,
    );
    _dialogController.forward();
  }

  @override
  void dispose() {
    _dialogController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.check_circle,
              color: BMIResult.getCategoryColor(widget.result.category),
            ),
            SizedBox(width: 8),
            Text('Your BMI Result'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TweenAnimationBuilder(
              duration: Duration(milliseconds: 600),
              tween: Tween<double>(begin: 0, end: widget.result.bmi),
              builder: (context, double value, child) {
                return Text(
                  'BMI: ${value.toStringAsFixed(1)}',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: BMIResult.getCategoryColor(widget.result.category),
                  ),
                );
              },
            ),
            SizedBox(height: 8),
            AnimatedContainer(
              duration: Duration(milliseconds: 500),
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: BMIResult.getCategoryColor(widget.result.category),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                widget.result.category,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Health Suggestions:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(widget.result.suggestion),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }
}
