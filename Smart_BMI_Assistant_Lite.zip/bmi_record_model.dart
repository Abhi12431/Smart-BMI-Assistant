import 'package:hive/hive.dart';

part 'bmi_record_model.g.dart';

@HiveType(typeId: 1)
class BmiRecordModel extends HiveObject {
  @HiveField(0)
  double bmi;

  @HiveField(1)
  double weight;

  @HiveField(2)
  double height;

  @HiveField(3)
  int age;

  @HiveField(4)
  String gender;

  @HiveField(5)
  String category;

  @HiveField(6)
  DateTime date;

  @HiveField(7)
  String suggestion;

  BmiRecordModel({
    required this.bmi,
    required this.weight,
    required this.height,
    required this.age,
    required this.gender,
    required this.category,
    required this.date,
    required this.suggestion,
  });

  BmiRecordModel copyWith({
    double? bmi,
    double? weight,
    double? height,
    int? age,
    String? gender,
    String? category,
    DateTime? date,
    String? suggestion,
  }) {
    return BmiRecordModel(
      bmi: bmi ?? this.bmi,
      weight: weight ?? this.weight,
      height: height ?? this.height,
      age: age ?? this.age,
      gender: gender ?? this.gender,
      category: category ?? this.category,
      date: date ?? this.date,
      suggestion: suggestion ?? this.suggestion,
    );
  }
}
