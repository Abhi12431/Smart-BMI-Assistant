import 'package:flutter/material.dart';

// Responsive helper functions
double w(BuildContext context) => MediaQuery.of(context).size.width;
double h(BuildContext context) => MediaQuery.of(context).size.height;
