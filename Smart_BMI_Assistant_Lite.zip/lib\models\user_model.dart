import 'package:hive/hive.dart';

part 'user_model.g.dart';

@HiveType(typeId: 0)
class UserModel extends HiveObject {
  @HiveField(0)
  String name;

  @HiveField(1)
  int age;

  @HiveField(2)
  double height;

  @HiveField(3)
  double weight;

  @HiveField(4)
  String goal;

  @HiveField(5)
  String gender;

  @HiveField(6)
  DateTime createdAt;

  UserModel({
    required this.name,
    required this.age,
    required this.height,
    required this.weight,
    required this.goal,
    required this.gender,
    required this.createdAt,
  });

  UserModel copyWith({
    String? name,
    int? age,
    double? height,
    double? weight,
    String? goal,
    String? gender,
    DateTime? createdAt,
  }) {
    return UserModel(
      name: name ?? this.name,
      age: age ?? this.age,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      goal: goal ?? this.goal,
      gender: gender ?? this.gender,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
