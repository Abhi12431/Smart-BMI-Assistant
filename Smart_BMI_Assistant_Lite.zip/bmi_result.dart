import 'package:flutter/material.dart';

class BMIResult {
  final String? id;
  final double bmi;
  final String category;
  final String suggestion;
  final DateTime date;
  final double weight;
  final double height;
  final int age;
  final String gender;

  BMIResult({
    this.id,
    required this.bmi,
    required this.category,
    required this.suggestion,
    required this.date,
    required this.weight,
    required this.height,
    required this.age,
    required this.gender,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'bmi': bmi,
      'category': category,
      'suggestion': suggestion,
      'date': date.toIso8601String(),
      'weight': weight,
      'height': height,
      'age': age,
      'gender': gender,
    };
  }

  factory BMIResult.fromJson(Map<String, dynamic> json) {
    return BMIResult(
      id: json['id'] as String?,
      bmi: json['bmi'],
      category: json['category'],
      suggestion: json['suggestion'],
      date: DateTime.parse(json['date']),
      weight: json['weight'],
      height: json['height'],
      age: json['age'],
      gender: json['gender'],
    );
  }

  static String getBMICategory(double bmi) {
    if (bmi < 16) return 'Severely Underweight';
    if (bmi < 18.5) return 'Underweight';
    if (bmi < 25) return 'Normal Weight';
    if (bmi < 30) return 'Overweight';
    if (bmi < 35) return 'Obese Class I';
    if (bmi < 40) return 'Obese Class II';
    return 'Obese Class III';
  }

  static Color getCategoryColor(String category) {
    switch (category) {
      case 'Severely Underweight':
        return Colors.blue.shade900;
      case 'Underweight':
        return Colors.blue;
      case 'Normal Weight':
        return Colors.green;
      case 'Overweight':
        return Colors.orange;
      case 'Obese Class I':
        return Colors.red.shade300;
      case 'Obese Class II':
        return Colors.red.shade600;
      case 'Obese Class III':
        return Colors.red.shade900;
      default:
        return Colors.grey;
    }
  }

  static String getHealthSuggestion(String category, int age, String gender) {
    switch (category) {
      case 'Severely Underweight':
        return '''Your BMI indicates severe underweight. Consider:
• Consult a healthcare provider immediately
• Increase calorie intake with nutrient-dense foods
• Include protein-rich foods in every meal
• Consider strength training to build muscle mass
• Eat frequent small meals throughout the day''';
      
      case 'Underweight':
        return '''Your BMI indicates you're underweight. Suggestions:
• Increase calorie intake by 300-500 calories daily
• Focus on protein, healthy fats, and complex carbs
• Include nuts, seeds, and avocados in your diet
• Consider resistance training exercises
• Ensure adequate sleep and rest''';
      
      case 'Normal Weight':
        return '''Congratulations! Your BMI is in the healthy range. Tips:
• Maintain your current balanced diet
• Continue regular physical activity (150 mins/week)
• Monitor weight changes monthly
• Stay hydrated and get adequate sleep
• Continue regular health check-ups''';
      
      case 'Overweight':
        return '''Your BMI indicates overweight. Recommendations:
• Create a modest calorie deficit (500 calories/day)
• Increase physical activity to 300 mins/week
• Focus on whole foods and reduce processed foods
• Practice portion control
• Consider consulting a nutritionist''';
      
      case 'Obese Class I':
        return '''Your BMI indicates Class I obesity. Important steps:
• Aim for 5-10% weight loss for health benefits
• Consult healthcare provider for guidance
• Start with low-impact exercises (walking, swimming)
• Focus on portion control and mindful eating
• Monitor blood pressure and blood sugar regularly''';
      
      case 'Obese Class II':
        return '''Your BMI indicates Class II obesity. Medical attention recommended:
• Seek medical supervision for weight management
• Consider professional nutrition counseling
• Start with gentle exercises under guidance
• Address any underlying health conditions
• Set realistic, gradual weight loss goals''';
      
      case 'Obese Class III':
        return '''Your BMI indicates Class III obesity. Immediate medical care advised:
• Consult healthcare provider immediately
• Comprehensive medical evaluation needed
• Consider supervised weight management program
• Address potential comorbidities
• Professional dietary and exercise guidance essential''';
      
      default:
        return 'Consult a healthcare provider for personalized advice.';
    }
  }
}
