// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'diet_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DietModelAdapter extends TypeAdapter<DietModel> {
  @override
  final int typeId = 2;

  @override
  DietModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DietModel(
      type: fields[0] as String,
      bmiCategory: fields[1] as String,
      meals: (fields[2] as List).cast<MealModel>(),
      waterIntake: fields[3] as String,
      exerciseTip: fields[4] as String,
      suggestions: (fields[5] as List).cast<String>(),
      dailyCalories: fields[6] as int,
      createdAt: fields[7] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, DietModel obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.type)
      ..writeByte(1)
      ..write(obj.bmiCategory)
      ..writeByte(2)
      ..write(obj.meals)
      ..writeByte(3)
      ..write(obj.waterIntake)
      ..writeByte(4)
      ..write(obj.exerciseTip)
      ..writeByte(5)
      ..write(obj.suggestions)
      ..writeByte(6)
      ..write(obj.dailyCalories)
      ..writeByte(7)
      ..write(obj.createdAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DietModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class MealModelAdapter extends TypeAdapter<MealModel> {
  @override
  final int typeId = 3;

  @override
  MealModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return MealModel(
      name: fields[0] as String,
      time: fields[1] as String,
      calories: fields[2] as int,
      items: (fields[3] as List).cast<String>(),
    );
  }

  @override
  void write(BinaryWriter writer, MealModel obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.name)
      ..writeByte(1)
      ..write(obj.time)
      ..writeByte(2)
      ..write(obj.calories)
      ..writeByte(3)
      ..write(obj.items);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MealModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
