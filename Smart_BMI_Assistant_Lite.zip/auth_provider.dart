import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import '../services/hive_service.dart';
import '../models/user_profile.dart';
import '../models/user_model.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();

  UserProfile? _userProfile;
  bool _isLoading = false;
  String? _errorMessage;
  bool _isAuthenticated = false;
  bool _hasSignedUp = false;
  String? _userEmail;

  UserProfile? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _isAuthenticated;
  bool get hasSignedUp => _hasSignedUp;
  String? get userEmail => _userEmail;

  // Initialize auth state
  Future<void> initAuth() async {
    _isAuthenticated = await _authService.isAuthenticated;
    _hasSignedUp = await _authService.hasSignedUp;
    _userEmail = await _authService.currentUserEmail;
    if (_isAuthenticated) {
      await loadUserProfile();
    }
    notifyListeners();
  }

  // Sign up with email and password
  Future<bool> signUp({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final success = await _authService.signUp(email: email, password: password);

      if (success) {
        _userEmail = await _authService.currentUserEmail;
        _isAuthenticated = true;
        _hasSignedUp = true;
        _isLoading = false;
        notifyListeners();
        return true;
      }
      _isLoading = false;
      _errorMessage = 'Invalid credentials or already signed up';
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Sign up with email, password, and profile data
  Future<bool> signUpWithProfile({
    required String email,
    required String password,
    required String name,
    required int age,
    required double height,
    required double weight,
    required String gender,
    required String goal,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final success = await _authService.signUp(email: email, password: password);

      if (success) {
        _userEmail = await _authService.currentUserEmail;
        _isAuthenticated = true;
        _hasSignedUp = true;
        
        // Save profile data to Hive
        final userModel = UserModel(
          name: name,
          age: age,
          height: height,
          weight: weight,
          gender: gender,
          goal: goal,
          createdAt: DateTime.now(),
        );
        await HiveService.saveUser(userModel, email);
        
        // Also save to SharedPreferences for AuthProvider
        final profile = UserProfile(
          id: _userEmail ?? 'unknown',
          name: name,
          email: _userEmail ?? email,
          age: age,
          height: height,
          weight: weight,
          gender: gender,
          goal: goal,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await saveUserProfileLocally(profile);
        _userProfile = profile;
        
        _isLoading = false;
        notifyListeners();
        return true;
      }
      _isLoading = false;
      _errorMessage = 'Invalid credentials or already signed up';
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Login with email and password
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final success = await _authService.login(email: email, password: password);

      if (success) {
        _userEmail = await _authService.currentUserEmail;
        _isAuthenticated = true;
        await loadUserProfile();
        _isLoading = false;
        notifyListeners();
        return true;
      }
      _isLoading = false;
      _errorMessage = 'Invalid email or password. Please sign up first.';
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      await _authService.signOut();
      _userProfile = null;
      _errorMessage = null;
      _isAuthenticated = false;
      _userEmail = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Load user profile from local storage
  Future<void> loadUserProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userName = prefs.getString('user_name');
      
      if (userName != null) {
        _userProfile = UserProfile(
          id: _userEmail ?? 'unknown',
          name: userName,
          email: _userEmail ?? 'user@local.app',
          age: prefs.getInt('user_age') ?? 25,
          height: prefs.getDouble('user_height') ?? 170.0,
          weight: prefs.getDouble('user_weight') ?? 70.0,
          gender: prefs.getString('user_gender') ?? 'Male',
          goal: prefs.getString('user_goal') ?? 'Maintain Weight',
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Save user profile locally
  Future<void> saveUserProfileLocally(UserProfile profile) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_name', profile.name);
      await prefs.setInt('user_age', profile.age);
      await prefs.setDouble('user_height', profile.height);
      await prefs.setDouble('user_weight', profile.weight);
      await prefs.setString('user_gender', profile.gender);
      await prefs.setString('user_goal', profile.goal);
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Update user profile
  Future<bool> updateProfile(UserProfile profile) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await saveUserProfileLocally(profile);
      _userProfile = profile;
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Clear error message
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
