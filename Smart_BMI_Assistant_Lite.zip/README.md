# Smart BMI Assistant

A comprehensive Flutter application for calculating BMI (Body Mass Index) with personalized health suggestions and history tracking.

## Features

- **BMI Calculator**: Calculate BMI based on height, weight, age, and gender
- **Personalized Suggestions**: Get health recommendations based on your BMI category
- **History Tracking**: View and track your BMI measurements over time with charts
- **Data Persistence**: All data is stored locally on your device
- **Beautiful UI**: Modern, intuitive interface with Material Design 3

## BMI Categories

The app categorizes BMI into the following ranges:
- **Severely Underweight**: BMI < 16
- **Underweight**: BMI 16 - 18.5
- **Normal Weight**: BMI 18.5 - 25
- **Overweight**: BMI 25 - 30
- **Obese Class I**: BMI 30 - 35
- **Obese Class II**: BMI 35 - 40
- **Obese Class III**: BMI > 40

## Health Suggestions

Based on your BMI category, the app provides personalized recommendations for:
- Dietary guidelines
- Exercise recommendations
- Lifestyle tips
- Medical advice when necessary

## Getting Started

### Prerequisites

- Flutter SDK (>=3.0.0)
- Dart SDK (>=3.0.0)
- Android Studio or VS Code
- Android SDK for Android development

### Installation

1. Clone this repository
2. Navigate to the project directory
3. Install dependencies:
   ```bash
   flutter pub get
   ```
4. Run the app:
   ```bash
   flutter run
   ```

### Dependencies

- `shared_preferences`: For local data storage
- `fl_chart`: For BMI history charts
- `google_fonts`: For beautiful typography
- `intl`: For date formatting

## App Structure

```
lib/
├── main.dart                 # App entry point
├── models/
│   └── bmi_result.dart       # BMI result model
└── screens/
    ├── bmi_calculator_screen.dart  # Main BMI calculator
    ├── history_screen.dart         # BMI history with charts
    └── suggestions_screen.dart     # Health suggestions
```

## How to Use

1. **Calculate BMI**: Enter your height, weight, age, and gender
2. **View Results**: See your BMI value and category with color coding
3. **Get Suggestions**: Access personalized health recommendations
4. **Track History**: View your BMI trends over time with interactive charts

## Data Storage

All BMI data is stored locally using SharedPreferences:
- Results are saved as JSON
- Maximum 50 results are stored (oldest removed when limit reached)
- Data persists between app sessions

## BMI Formula

BMI is calculated using the standard formula:
```
BMI = weight (kg) / (height (m))²
```

## Medical Disclaimer

This app provides general health suggestions and should not replace professional medical advice. Always consult with healthcare providers for personalized medical recommendations.

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is licensed under the MIT License.
