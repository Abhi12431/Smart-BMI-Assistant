class DietPlan {
  final String category;
  final String goal;
  final List<Meal> meals;
  final int dailyCalories;
  final List<String> suggestions;
  final String waterIntake;
  final String exerciseTip;

  DietPlan({
    required this.category,
    required this.goal,
    required this.meals,
    required this.dailyCalories,
    required this.suggestions,
    required this.waterIntake,
    required this.exerciseTip,
  });

  factory DietPlan.fromBMICategory(String bmiCategory) {
    switch (bmiCategory.toLowerCase()) {
      case 'underweight':
        return DietPlan.weightGain();
      case 'normal':
        return DietPlan.maintenance();
      case 'overweight':
      case 'obese':
        return DietPlan.weightLoss();
      default:
        return DietPlan.maintenance();
    }
  }

  factory DietPlan.weightGain() {
    return DietPlan(
      category: 'Underweight',
      goal: 'Weight Gain',
      dailyCalories: 2500,
      waterIntake: '2.5-3 liters per day',
      exerciseTip: 'Focus on strength training with moderate cardio',
      meals: [
        Meal(
          name: 'Breakfast',
          time: '7:00 AM',
          calories: 600,
          items: [
            '3 large eggs (scrambled with cheese)',
            '2 slices whole wheat toast with butter',
            '1 banana',
            '1 glass whole milk (300ml)',
            'Handful of almonds',
          ],
        ),
        Meal(
          name: 'Lunch',
          time: '1:00 PM',
          calories: 800,
          items: [
            'Grilled chicken breast (200g)',
            '1 cup brown rice',
            'Steamed vegetables with olive oil',
            'Avocado salad',
            'Full-fat yogurt',
          ],
        ),
        Meal(
          name: 'Dinner',
          time: '7:00 PM',
          calories: 750,
          items: [
            'Salmon fillet (200g)',
            'Sweet potato with butter',
            'Quinoa salad',
            'Mixed nuts',
            'Glass of whole milk',
          ],
        ),
        Meal(
          name: 'Snacks',
          time: 'Throughout day',
          calories: 350,
          items: [
            'Protein shake',
            'Peanut butter sandwich',
            'Dried fruits',
            'Cheese cubes',
          ],
        ),
      ],
      suggestions: [
        'Eat 5-6 small meals throughout the day',
        'Include protein in every meal',
        'Add healthy fats (avocado, nuts, olive oil)',
        'Drink milk and consume dairy products',
        'Avoid skipping meals',
        'Get adequate sleep (7-8 hours)',
        'Consider weight gainer supplements',
      ],
    );
  }

  factory DietPlan.maintenance() {
    return DietPlan(
      category: 'Normal',
      goal: 'Maintenance',
      dailyCalories: 2000,
      waterIntake: '2-2.5 liters per day',
      exerciseTip: 'Balanced mix of cardio and strength training',
      meals: [
        Meal(
          name: 'Breakfast',
          time: '7:00 AM',
          calories: 450,
          items: [
            '2 eggs (boiled or poached)',
            '1 slice whole wheat toast',
            '1 small apple',
            '1 glass low-fat milk',
            'Handful of mixed nuts',
          ],
        ),
        Meal(
          name: 'Lunch',
          time: '1:00 PM',
          calories: 650,
          items: [
            'Grilled chicken or fish (150g)',
            '1/2 cup brown rice',
            'Large salad with light dressing',
            'Steamed vegetables',
            'Fresh fruit',
          ],
        ),
        Meal(
          name: 'Dinner',
          time: '7:00 PM',
          calories: 600,
          items: [
            'Lean protein (chicken/fish/tofu)',
            '1/2 cup quinoa or brown rice',
            'Roasted vegetables',
            'Green salad',
            'Herbal tea',
          ],
        ),
        Meal(
          name: 'Snacks',
          time: 'Throughout day',
          calories: 300,
          items: [
            'Greek yogurt with berries',
            'Hummus with vegetables',
            'Small handful of nuts',
            'Fresh fruit',
          ],
        ),
      ],
      suggestions: [
        'Maintain balanced diet with all food groups',
        'Eat 3 main meals + 2 healthy snacks',
        'Stay hydrated throughout the day',
        'Limit processed foods and sugars',
        'Exercise regularly (150 mins/week)',
        'Get 7-8 hours of sleep',
        'Practice mindful eating',
      ],
    );
  }

  factory DietPlan.weightLoss() {
    return DietPlan(
      category: 'Overweight/Obese',
      goal: 'Weight Loss',
      dailyCalories: 1500,
      waterIntake: '3-4 liters per day',
      exerciseTip: 'Focus on cardio with some strength training',
      meals: [
        Meal(
          name: 'Breakfast',
          time: '7:00 AM',
          calories: 350,
          items: [
            '2 egg whites',
            '1 slice whole wheat toast (dry)',
            '1/2 grapefruit',
            'Black coffee or green tea',
            'Small handful of berries',
          ],
        ),
        Meal(
          name: 'Lunch',
          time: '1:00 PM',
          calories: 450,
          items: [
            'Grilled chicken breast (100g)',
            'Large green salad with lemon dressing',
            '1/2 cup steamed vegetables',
            'Clear vegetable soup',
            'Fresh fruit (apple/pear)',
          ],
        ),
        Meal(
          name: 'Dinner',
          time: '7:00 PM',
          calories: 400,
          items: [
            'Grilled fish or tofu (100g)',
            'Large vegetable salad',
            'Steamed broccoli and cauliflower',
            'Herbal tea',
            'No carbohydrates after 6 PM',
          ],
        ),
        Meal(
          name: 'Snacks',
          time: 'Throughout day',
          calories: 300,
          items: [
            'Cucumber slices with hummus',
            'Green tea',
            'Small apple',
            'Carrot sticks',
          ],
        ),
      ],
      suggestions: [
        'Create calorie deficit of 500-750 calories',
        'Eat more fiber-rich foods',
        'Increase protein intake to feel full',
        'Avoid sugary drinks and processed foods',
        'Exercise 5-6 days per week',
        'Include both cardio and strength training',
        'Get 7-8 hours of quality sleep',
        'Practice portion control',
        'Drink water before meals',
        'Avoid eating late at night',
      ],
    );
  }
}

class Meal {
  final String name;
  final String time;
  final int calories;
  final List<String> items;

  Meal({
    required this.name,
    required this.time,
    required this.calories,
    required this.items,
  });
}
