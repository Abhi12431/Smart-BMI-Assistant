import 'package:hive_flutter/hive_flutter.dart';
import '../models/user_model.dart';
import '../models/bmi_record_model.dart';
import '../models/diet_model.dart';

class HiveService {
  static const String _userBoxName = 'userBox';
  static const String _bmiBoxName = 'bmiBox';
  static const String _dietBoxName = 'dietBox';

  static late Box<UserModel> _userBox;
  static late Box<BmiRecordModel> _bmiBox;
  static late Box<DietModel> _dietBox;

  // Initialize Hive and open boxes
  static Future<void> init() async {
    await Hive.initFlutter();
    
    // Register adapters
    Hive.registerAdapter(UserModelAdapter());
    Hive.registerAdapter(BmiRecordModelAdapter());
    Hive.registerAdapter(DietModelAdapter());
    Hive.registerAdapter(MealModelAdapter());

    // Open boxes
    _userBox = await Hive.openBox<UserModel>(_userBoxName);
    _bmiBox = await Hive.openBox<BmiRecordModel>(_bmiBoxName);
    _dietBox = await Hive.openBox<DietModel>(_dietBoxName);
  }

  // ============ USER OPERATIONS ============
  
  // Save user profile with email key
  static Future<void> saveUser(UserModel user, String email) async {
    await _userBox.put('profile_$email', user);
  }

  // Get current user by email
  static UserModel? getUserByEmail(String email) {
    return _userBox.get('profile_$email');
  }

  // Save user profile (legacy - for backward compatibility)
  static Future<void> saveCurrentUser(UserModel user) async {
    await _userBox.put('currentUser', user);
  }

  // Get current user (legacy - for backward compatibility)
  static UserModel? getCurrentUser() {
    return _userBox.get('currentUser');
  }

  // Delete user by email
  static Future<void> deleteUserByEmail(String email) async {
    await _userBox.delete('profile_$email');
  }

  // Delete user (legacy)
  static Future<void> deleteUser() async {
    await _userBox.delete('currentUser');
  }

  // ============ BMI RECORD OPERATIONS ============
  
  // Save BMI record
  static Future<void> saveBmiRecord(BmiRecordModel record) async {
    await _bmiBox.add(record);
  }

  // Get all BMI records
  static List<BmiRecordModel> getAllBmiRecords() {
    return _bmiBox.values.toList();
  }

  // Get latest BMI record
  static BmiRecordModel? getLatestBmiRecord() {
    if (_bmiBox.isEmpty) return null;
    return _bmiBox.values.last;
  }

  // Get BMI records by date range
  static List<BmiRecordModel> getBmiRecordsByDateRange(DateTime start, DateTime end) {
    return _bmiBox.values
        .where((record) => record.date.isAfter(start) && record.date.isBefore(end))
        .toList();
  }

  // Delete BMI record
  static Future<void> deleteBmiRecord(int index) async {
    await _bmiBox.deleteAt(index);
  }

  // Clear all BMI records
  static Future<void> clearAllBmiRecords() async {
    await _bmiBox.clear();
  }

  // Get BMI statistics
  static Map<String, dynamic> getBmiStatistics() {
    final records = _bmiBox.values.toList();
    if (records.isEmpty) {
      return {
        'average': 0.0,
        'min': 0.0,
        'max': 0.0,
        'count': 0,
      };
    }

    final bmiValues = records.map((r) => r.bmi).toList();
    return {
      'average': bmiValues.reduce((a, b) => a + b) / bmiValues.length,
      'min': bmiValues.reduce((a, b) => a < b ? a : b),
      'max': bmiValues.reduce((a, b) => a > b ? a : b),
      'count': records.length,
    };
  }

  // ============ DIET PLAN OPERATIONS ============
  
  // Save diet plan
  static Future<void> saveDietPlan(DietModel diet) async {
    await _dietBox.put('currentDiet', diet);
  }

  // Get current diet plan
  static DietModel? getCurrentDietPlan() {
    return _dietBox.get('currentDiet');
  }

  // Delete diet plan
  static Future<void> deleteDietPlan() async {
    await _dietBox.delete('currentDiet');
  }

  // ============ UTILITY OPERATIONS ============
  
  // Close all boxes
  static Future<void> close() async {
    await _userBox.close();
    await _bmiBox.close();
    await _dietBox.close();
  }

  // Clear all data
  static Future<void> clearAllData() async {
    await _userBox.clear();
    await _bmiBox.clear();
    await _dietBox.clear();
  }
}
